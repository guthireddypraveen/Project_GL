-- TASK2
-- 2.(Medium) Perform read operation on the designed table created in the above task using SQL script. 
-- a.How many females and how many male passengers traveled a minimum distance of 600 KMs?
show databases;
USE Travego;

SELECT Gender, COUNT(*) as Total 
FROM Passenger 
WHERE Distance >= 600 
GROUP BY Gender;

-- b. Here's the SQL code to find the minimum ticket price of a Sleeper Bus:( MINIORICE-770)

SELECT MIN(Price) as MinPrice 
FROM Price 
WHERE Bus_type = 'Sleeper';

-- c. Here's the SQL code to select passenger names whose names start with the character 'S': SEJAL

SELECT Passenger_name 
FROM Passenger 
WHERE Passenger_name LIKE 'S%';

-- d. Here's the SQL code to calculate the price charged for each passenger and display Passenger name, Boarding City, Destination City, Bus_Type, and Price in the output:

SELECT p.Passenger_name, p.Boarding_City, p.Destination_City, p.Bus_Type, pr.Price 
FROM Passenger p 
JOIN Price pr ON p.Distance = pr.Distance AND p.Bus_Type = pr.Bus_type;

-- e. Here's the SQL code to find out the passenger name(s) and the ticket price for those who traveled 1000 KMs Sitting in a bus:

SELECT p.Passenger_name, pr.Price 
FROM Passenger p 
JOIN Price pr ON p.Bus_Type = pr.Bus_type AND p.Distance = pr.Distance 
WHERE p.Bus_Type = 'Sitting' AND p.Distance = 1000;

-- f. Here's the SQL code to find the Sitting and Sleeper bus charge for Pallavi to travel from Bangalore to Panaji:

SELECT p.Bus_Type, pr.Price 
FROM Passenger p 
JOIN Price pr ON p.Bus_Type = pr.Bus_type AND p.Distance = pr.Distance 
WHERE p.Passenger_name = 'Pallavi' AND p.Boarding_City = 'Panaji' AND p.Destination_City = 'Bengaluru';

-- g. Here's the SQL code to list the unique (non-repeated) distances from the "Passenger" table in descending order:

SELECT DISTINCT Distance 
FROM Passenger 
ORDER BY Distance DESC;

-- h. Here's the SQL code to display the passenger name and percentage of distance traveled by that passenger from the total distance traveled by all passengers without using user variables:

SELECT p.Passenger_name, CONCAT(ROUND((p.Distance / t.TotalDistance) * 100, 2), '%') AS DistancePercentage 
FROM Passenger p 
JOIN (SELECT SUM(Distance) AS TotalDistance FROM Passenger) t 
ORDER BY DistancePercentage DESC;